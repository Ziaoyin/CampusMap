/*
 * Copyright (C) 2023 Soham Pardeshi.  All rights reserved.  Permission is
 * hereby granted to students registered for University of Washington
 * CSE 331 for use solely during Spring Quarter 2021 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.  Instructors
 * interested in reusing these course materials should contact the
 * author.
 */

package sets;

import java.util.List;

/**
 * Represents an immutable set of points on the real line that is easy to
 * describe, either because it is a finite set, e.g., {p1, p2, ..., pN}, or
 * because it excludes only a finite set, e.g., R \ {p1, p2, ..., pN}. As with
 * FiniteSet, each point is represented by a Java float with a non-infinite,
 * non-NaN value.
 */
public class SimpleSet {

  // TODO: fill in and document the representation
  //       Make sure to include the representation invariant (RI)
  //       and the abstraction function (AF).

  //   RI: set != null
  //
  //   AF(this) = {set}        if isComplement is false,
  //              {R-set}      otherwise

  private final FiniteSet set;
  private final boolean isComplement;


  /**
   * Creates a simple set containing only the given points.
   * @param vals Array containing the points to make into a SimpleSet
   * @spec.requires points != null and has no NaNs, no infinities, and no dups
   * @spec.effects this = {vals[0], vals[1], ..., vals[vals.length-1]}
   */
  public SimpleSet(float[] vals) {
    this(FiniteSet.of(vals), false);
  }

  // HINT: feel free to create other constructors!

  /**
   * Creates a simple set containing only the given points or the complement.
   * @param other FiniteSet containing a finite set of values
   * @param value boolean representing whether or not this set is a complement
   * @spec.requires other != null
   * @spec.effects this = {other} if value is false
   *               this = {R-other} if value is true
   */
  private SimpleSet(FiniteSet other, boolean value) {
    this.set = other;
    this.isComplement = value;
  }
  @Override
  public boolean equals(Object o) {
    if (!(o instanceof SimpleSet))
      return false;

    SimpleSet other = (SimpleSet) o;

    // to be equal, both sets must be a complement of a finite set or a finite set. The points
    // in/not in the set must also be the same to be an equal set.
    return (this.isComplement == other.isComplement) && (this.set.equals(other.set));
  }

  @Override
  public int hashCode() {
    return super.hashCode();
  }

  /**
   * Returns the number of points in this set.
   * @return N      if this = {p1, p2, ..., pN} and
   *         infty  if this = R \ {p1, p2, ..., pN}
   */
  public float size() {
    // TODO: implement this
    if (isComplement) { // is a complement of a finite set, meaning it is infinite in size
      return Float.POSITIVE_INFINITY;
    } else { // is a finite size, so just return the set size
      return set.size();
    }
  }

  /**
   * Returns a string describing the points included in this set.
   * @return the string "R" if this contains every point,
   *     a string of the form "R \ {p1, p2, .., pN}" if this contains all
   *        but {@literal N > 0} points, or
   *     a string of the form "{p1, p2, .., pN}" if this contains
   *        {@literal N >= 0} points,
   *     where p1, p2, ... pN are replaced by the individual numbers. These
   *     floats will be turned into strings in the standard manner (the same as
   *     done by, e.g., String.valueOf(float)).
   */
  public String toString() {
    // TODO: implement this with a loop. document its invariant
    //       a StringBuilder may be useful for creating the string
    if (isComplement && set.getPoints().isEmpty()) { // all points in R
      return "R";
    }

    StringBuilder toReturn = new StringBuilder("{");
    List<Float> list = set.getPoints();
    int i = 0;
    // Inv: toReturn = {p(1), p(2), ... , p(i)
    // where p(x) is the xth value in the set (1-based indexing)
    while (i < list.size()) {
      toReturn.append(list.get(i));
      if (i < list.size()-1) {
        toReturn.append(", ");
      }
      i++;
    }

    // by now we know toReturn = {p(1), p(2), ... , p(i) and that i = size() = N.
    toReturn.append("}");
    // now toReturn = {p(1), p(2), ... , p(N)}

    if (isComplement) { // only if complement of finite set
      toReturn.insert(0, "R \\ ");
    }
    return toReturn.toString();
  }

  /**
   * Returns a set representing the points R \ this.
   * @return R \ this
   */
  public SimpleSet complement() {
    // TODO: implement this method
    //       include sufficient comments to see why it is correct (hint: cases)

    // returns a new set that now is everything in R not in this.set
    // if it was complement, now it is still the same "set" but isComplement is false
    // if it wasn't a complement, now it is still the same "set" but isComplement is true
    return new SimpleSet(this.set, !isComplement);
  }

  /**
   * Returns the union of this and other.
   * @param other Set to union with this one.
   * @spec.requires other != null
   * @return this union other
   */
  public SimpleSet union(SimpleSet other) {
    // TODO: implement this method
    //       include sufficient comments to see why it is correct (hint: cases)

    // For simplicity, A = this.set, B = other.set, and domain is R
    if (!this.isComplement && !other.isComplement) { // both finite
      // union of two finite sets work because of FiniteSet.union()
      return new SimpleSet(this.set.union(other.set), false);
    } else if (!this.isComplement) { // other is a complement of a finite set (A U B')
      // For an element to be a part of A U B', they would also have to be in (B - A)'. If an element were
      // to be in A, it would not be in B - A, therefore would be in (B - A)'. If an element were in B', it
      // would not be in B, therefore also not be in B - A and in (B - A)'.
      //
      // For an element to be a part of (B - A)', they would also have to be in A U B'. If an element weren't
      // to be in B - A, they would be in A or not in B. In both cases, they would be in A U B'.
      //
      // Since A U B' and (B - A)' are mutual subsets, we can say they are equal.

      return new SimpleSet(other.set.difference(this.set), true);
    } else if (!other.isComplement) { // this is a complement of a finite set (A' U B)
      // The same logic above applies, just with A and B switched
      return new SimpleSet(this.set.difference(other.set), true);
    } else { // both are complements of a finite set (A' U B')
      // Taking a double complement doesn't change the property of a set so (A' U B') = (A' U B')''.
      // By DeMorgan's Law, (A' U B')'' = (A ∩ B)'.
      return new SimpleSet(this.set.intersection(other.set), true);
    }
  }

  /**
   * Returns the intersection of this and other.
   * @param other Set to intersect with this one.
   * @spec.requires other != null
   * @return this intersected with other
   */
  public SimpleSet intersection(SimpleSet other) {
    // TODO: implement this method
    //       include sufficient comments to see why it is correct
    // NOTE: There is more than one correct way to implement this.

    // For simplicity, A = this.set, B = other.set, and domain is R
    if (!this.isComplement && !other.isComplement) { // both finite (A ∩ B)
      // Since both are finite, we can use FiniteSet.intersection()
      return new SimpleSet(this.set.intersection(other.set), false);
    } else if (!this.isComplement){ // other is complement (A ∩ B')
      // If an element is a part of A ∩ B', it must be in A and not in B. This is the definition
      // of A - B.
      //
      // If an element is a part of A - B, it is in A and not in B. That means it is also in A and B'.
      // By the definition of intersection, it is also in A ∩ B'.
      //
      // Since A ∩ B' and A - B are mutual subsets, we can say they are equal.
      return new SimpleSet(this.set.difference(other.set), false);
    } else if (!other.isComplement) { // this is complement (A' ∩ B)
      // The same logic above applies, just with A and B switched
      return new SimpleSet(other.set.difference(this.set), false);
    } else { // both infinite (A' ∩ B')
      // Taking a double complement doesn't change the property of a set so (A' ∩ B') = (A' ∩ B')''.
      // By DeMorgan's Law, (A' ∩ B')'' = (A U B)'.
      return new SimpleSet(this.set.union(other.set),true);
    }
  }

  /**
   * Returns the difference of this and other.
   * @param other Set to difference from this one.
   * @spec.requires other != null
   * @return this minus other
   */
  public SimpleSet difference(SimpleSet other) {
    // TODO: implement this method
    //       include sufficient comments to see why it is correct
    // NOTE: There is more than one correct way to implement this.

    // For simplicity, A = this.set, B = other.set, and domain is R
    if (!this.isComplement && !other.isComplement) { // both finite (A - B)
      // Both are finite, so we can use FiniteSet.difference()
      return new SimpleSet(this.set.difference(other.set), false);
    } else if (!this.isComplement){ // other is complement (A - B')
      // If an element is in A - B', that means that it is in A but not in B'. This is the same as
      // saying it is in A and in B. By the definition of intersection, the element is in A ∩ B.
      //
      // If an element is in A ∩ B, it is in A and B. This is the same as saying it is in A and
      // not in B'. By definition of difference, A - B'.
      //
      // Since A - B' and A ∩ B are mutual subsets, we can say they are equal.
      return new SimpleSet(this.set.intersection(other.set), false);
    } else if (!other.isComplement) { // this is complement (A' - B)
      // If an element is in A' - B, that means that it is in A' but not in B. This is the same as
      // saying it is in A' and B', which is the same as A' ∩ B' by the definition of intersection.
      // By DeMorgans Law, (A' ∩ B') = (A' ∩ B')'' = (A U B)'.
      //
      // If an element is in (A U B)', that means it is not in A and not in B. We can simplify that to
      // be A' - B.
      //
      // Since A' - B and (A U B)' are mutual subsets, we can say they are equal.
      return new SimpleSet(other.set.union(this.set), true);
    } else { // both infinite (A' - B')
      // If an element is in A' - B', they are in A' and not in B'. This is the same as saying they
      // are not in A and in B. By the definition of difference, being in B but not in A is the
      // same as A - B.
      return new SimpleSet(other.set.difference(this.set),false);
    }
  }
}
