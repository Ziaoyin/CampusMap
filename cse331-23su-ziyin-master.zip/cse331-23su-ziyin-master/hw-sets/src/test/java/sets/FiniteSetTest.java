/*
 * Copyright (C) 2023 Soham Pardeshi.  All rights reserved.  Permission is
 * hereby granted to students registered for University of Washington
 * CSE 331 for use solely during Spring Quarter 2021 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.  Instructors
 * interested in reusing these course materials should contact the
 * author.
 */

package sets;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Arrays;

/**
 * FiniteSetTest is a glassbox test of the FiniteSet class.
 */
public class FiniteSetTest {

  ///////////////////////////////////////////////////////////////////////////
  /// FiniteSet.FiniteSet() Tests
  ///////////////////////////////////////////////////////////////////////////

  /**
   * Test creating basic sets.
   */
  @Test
  public void testCreationEmptySet() {
    assertEquals(Arrays.asList(),
        FiniteSet.of(new float[0]).getPoints());
  }

  /**
   * Test creating basic sets.
   */
  @Test
  public void testCreationBasic() {
    assertEquals(Arrays.asList(1f),
        FiniteSet.of(new float[] {1}).getPoints());      // one item
    assertEquals(Arrays.asList(1f, 2f),
        FiniteSet.of(new float[] {1, 2}).getPoints());   // two items
    assertEquals(Arrays.asList(1f, 2f),
        FiniteSet.of(new float[] {2, 1}).getPoints());   // two out-of-order
  }

  /**
   * Test creating a set that contains a negative point.
   */
  @Test
  public void testCreationNegative() {
    assertEquals(Arrays.asList(-2f, 2f),
        FiniteSet.of(new float[] {2, -2}).getPoints());
  }

  // Note:
  // The following are sets used throughout the rest of the tests.

  /** An empty set. */
  private static FiniteSet S0 = FiniteSet.of(new float[0]);

  /** A "singleton" set. */
  private static FiniteSet S1 = FiniteSet.of(new float[] {1});

  /** A "complex" set. Or, a set that contains more than one value. */
  private static FiniteSet S12 = FiniteSet.of(new float[] {1, 2});

  // TODO: Feel free to initialize additional (private static) FiniteSet
  //       objects here if you plan to use more of them for the tests you
  //       need to implement below.

  private static FiniteSet S34 = FiniteSet.of(new float[] {3, 4});
  private static FiniteSet S1234 = FiniteSet.of(new float[] {1, 2, 3, 4});

  private static FiniteSet S3 = FiniteSet.of(new float[] {3});

  private static FiniteSet S3456 = FiniteSet.of(new float[] {3, 4, 5, 6});

  private static FiniteSet N1 = FiniteSet.of(new float[] {-1});

  private static FiniteSet N123 = FiniteSet.of(new float[] {-1, -2, -3});

  private static FiniteSet N12 = FiniteSet.of(new float[] {-1, -2});

  private static FiniteSet N134 = FiniteSet.of(new float[] {-1, -3, -4});
  private static FiniteSet N1234 = FiniteSet.of(new float[] {-1, -2, -3, -4});



  ///////////////////////////////////////////////////////////////////////////
  /// FiniteSet.equals() Tests
  ///////////////////////////////////////////////////////////////////////////

  /**
   * Test set equality on an empty set.
   */
  @Test
  public void testEqualsEmptySet() {
    assertTrue(S0.equals(S0));
    assertFalse(S0.equals(S1));
    assertFalse(S0.equals(S12));
  }

  /**
   * Test set equality on a set containing one point.
   */
  @Test
  public void testEqualsSingleton() {
    assertFalse(S1.equals(S0));
    assertTrue(S1.equals(S1));
    assertFalse(S1.equals(S12));
  }

  /**
   * Test set equality on a set of multiple points.
   */
  @Test
  public void testEqualsComplexSet() {
    assertFalse(S12.equals(S0));
    assertFalse(S12.equals(S1));
    assertTrue(S12.equals(S12));
  }

  ///////////////////////////////////////////////////////////////////////////
  /// FiniteSet.size() Test
  ///////////////////////////////////////////////////////////////////////////

  /**
   * Test set size.
   */
  @Test
  public void testSize() {
    assertEquals(S0.size(), 0);
    assertEquals(S1.size(), 1);
    assertEquals(S12.size(), 2);
  }

  ///////////////////////////////////////////////////////////////////////////
  /// FiniteSet.union() Tests
  ///////////////////////////////////////////////////////////////////////////

  /**
   * Tests forming the union of two finite sets.
   */
  @Test
  public void testUnion() {
    // TODO: implement tests for FiniteSet.union()
    // tests union with empty stays the same
    assertEquals(S0, S0.union(S0));
    assertEquals(N1, N1.union(S0));
    assertEquals(N123, N123.union(S0));
    assertEquals(S1, S1.union(S0));
    assertEquals(S12, S12.union(S0));
    assertEquals(S1, S0.union(S1));
    assertEquals(S12, S0.union(S12));

    // tests union with same stays the same
    assertEquals(S0, S0.union(S0));
    assertEquals(N1, N1.union(N1));
    assertEquals(N12, N12.union(N12));
    assertEquals(S1, S1.union(S1));
    assertEquals(S12, S12.union(S12));
    assertEquals(S1234, S1234.union(S1234));

    // tests union with subsets stays the same
    assertEquals(S12, S12.union(S1));
    assertEquals(S1234, S1234.union(S1));
    assertEquals(S1234, S1234.union(S12));
    assertEquals(S1234, S1234.union(S34));
    assertEquals(N123, N123.union(N12));

    // tests union with new values
    assertEquals(S1234, S12.union(S34));
    assertEquals(S1234, S34.union(S12));
    assertEquals(N1234, N123.union(N134));
  }

  ///////////////////////////////////////////////////////////////////////////
  /// FiniteSet.intersection() Tests
  ///////////////////////////////////////////////////////////////////////////

  /**
   * Tests forming the intersection of two finite sets.
   */
  @Test
  public void testIntersection() {
    // TODO: implement tests for FiniteSet.intersection()
    // tests also test for commutative nature of intersection

    // tests intersection with empty causes empty sets
    assertEquals(S0, N1.intersection(S0));
    assertEquals(S0, N12.intersection(S0));
    assertEquals(S0, S0.intersection(S0));
    assertEquals(S0, S1.intersection(S0));
    assertEquals(S0, S12.intersection(S0));
    assertEquals(S0, S0.intersection(S1));
    assertEquals(S0, S0.intersection(S12));
    assertEquals(S0, S0.intersection(N1));
    assertEquals(S0, S0.intersection(N12));

    // tests intersection of identical sets
    assertEquals(N1, N1.intersection(N1));
    assertEquals(N12, N12.intersection(N12));
    assertEquals(S1, S1.intersection(S1));
    assertEquals(S12, S12.intersection(S12));
    assertEquals(S34, S34.intersection(S34));

    // tests intersection of disjoint sets
    assertEquals(S0, S12.intersection(S34));
    assertEquals(S0, S34.intersection(S12));
    assertEquals(S0, S1.intersection(S3));

    // test intersection of subset leads to subset
    assertEquals(S12, S1234.intersection(S12));
    assertEquals(S12, S12.intersection(S1234));
    assertEquals(S34, S1234.intersection(S34));
    assertEquals(S34, S34.intersection(S1234));
    assertEquals(N1, N123.intersection(N1));
    assertEquals(N1, N1.intersection(N123));
    assertEquals(N12, N12.intersection(N1234));

    // test intersection of partial overlap
    assertEquals(S34, S1234.intersection(S3456));
    assertEquals(S34, S3456.intersection(S1234));
    assertEquals(FiniteSet.of(new float[] {-1, -3}), N123.intersection(N134));
  }

  ///////////////////////////////////////////////////////////////////////////
  /// FiniteSet.difference() Tests
  ///////////////////////////////////////////////////////////////////////////

  /**
   * Tests forming the difference of two finite sets.
   */
  @Test
  public void testDifference() {
    // TODO: implement tests for FiniteSet.difference()
    // difference of empty set should remain the same
    assertEquals(N1, N1.difference(S0));
    assertEquals(N123, N123.difference(S0));
    assertEquals(S1, S1.difference(S0));
    assertEquals(S12, S12.difference(S0));

    // empty set difference should still be empty set
    assertEquals(S0, S0.difference(S0));
    assertEquals(S0, S0.difference(N1));
    assertEquals(S0, S0.difference(N12));
    assertEquals(S0, S0.difference(S12));
    assertEquals(S0, S0.difference(S1234));

    // difference of disjoint set should be original set
    assertEquals(S12, S12.difference(S34));
    assertEquals(S34, S34.difference(S12));
    assertEquals(S1, S1.difference(S3));
    assertEquals(S1234, S1234.difference(N1234));

    // difference of identical set should be 0
    assertEquals(S0, S1234.difference(S1234));
    assertEquals(S0, S12.difference(S12));
    assertEquals(S0, S1.difference(S1));
    assertEquals(S0, N12.difference(N12));
    assertEquals(S0, N1234.difference(N1234));
    assertEquals(S0, N1.difference(N1));

    // difference of subset should leave only unique values from superset
    assertEquals(S12, S1234.difference(S34));
    assertEquals(S34, S1234.difference(S12));
    assertEquals(FiniteSet.of(new float[] {-2}), N12.difference(N1));
  }
}
