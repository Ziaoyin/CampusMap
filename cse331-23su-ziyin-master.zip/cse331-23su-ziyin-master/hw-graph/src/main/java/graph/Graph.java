package graph;
import java.util.*;

/**
 * Represents a mutable graph containing nodes connected by edges.
 */
public class Graph<K,V> {
    private final Map<K, Set<Edge<K,V>>> map;
    public static final boolean DEBUG = false;

    // RI: map != null and elements of map.keySet() != null and map.get(x) != null for all
    // x in map.keySet() and elements of map.get(x) != null for all x in map.keySet() and
    // all elements in map.get(x) for all x in map.keySet() can be found in map.keySet()

    // AF(this) = (V, E) where V = map.keySet() and E = map.get(x) for all x in map.keySet()

    /**
     * Creates a Graph containing no vertices or edges
     * @spec.modifies this
     * @spec.effects this = empty graph
     */
    public Graph() {
        map = new HashMap<>();
        checkRep();
    }

    /**
     * Adds a vertex with the specified label to the graph
     * @param data the label associated with the new vertex
     * @spec.requires data != null
     * @spec.modifies this
     * @spec.effects adds vertex into this with no edges if no present vertex has the same label
     *               otherwise, nothing is modified
     */
    public void addVertex(K data) {
        checkRep();
        if (!map.containsKey(data)) {
            map.put(data, new HashSet<>());
        }
        checkRep();
    }

    /**
     * Adds an edge between the source and destination vertices with the specified label.
     * @param source the label associated with the source vertex of the edge
     * @param destination the label associated with the destination vertex of the edge
     * @param label the label associated with the new edge
     * @spec.requires source != null, destination != null, label != null
     * @spec.modifies this
     * @spec.effects adds the edge if no present edge with label between two nodes exist
     *              otherwise, this isn't modified
     *              if source or destination label doesn't exist, this isn't modified
     */
    public void addEdge(K source, K destination, V label) {
        checkRep();
        if (map.containsKey(source) && map.containsKey(destination)) {
            Edge<K,V> newEdge = new Edge<>(label, destination);
            map.get(source).add(newEdge);
        }
        checkRep();
    }


    /**
     * Checks if the graph contains a vertex with the given label
     * @param data the label associated with the vertex to be checked
     * @spec.requires data != null
     * @return true if the graph contains a vertex with the given label, otherwise false
     */
    public boolean hasVertex(K data) {
        checkRep();
        return map.containsKey(data);
    }

    /**
     * Checks if the graph contains an edge with the given label between the source and destination node
     * @param source the label associated with the source vertex of the edge
     * @param destination the label associated with the destination vertex of the edge
     * @param label the label associated with the edge between the vertices
     * @spec.requires source != null, destination != null, label != null
     * @return true if the graph contains the specified edge, otherwise false
     */
    public boolean hasEdge(K source, K destination, V label) {
        checkRep();
        if (map.containsKey(source) && map.containsKey(destination)) {
            for (Edge<K,V> edge : map.get(source)) {
                if (edge.destLabel.equals(destination) && edge.edgeLabel.equals(label)) {
                    checkRep();
                    return true;
                }
            }
        }
        checkRep();
        return false;
    }

    /**
     * Returns a set of all labels of edges from source to destination
     * @param source the label associated with the source vertex of the edge
     * @param destination the label associated with the destination vertex of the edge
     * @spec.requires source != null, destination != null
     * @return set of all labels of edges from source to destination
     *         if source or destination node doesn't exists, returns null
     */
    public Set<V> getLabel(K source, K destination) {
        checkRep();
        if (map.containsKey(source) && map.containsKey(destination)) {
            Set<V> set = new HashSet<>();
            for (Edge<K,V> edge : map.get(source)) {
                if (edge.destLabel.equals(destination)) {
                    set.add(edge.edgeLabel);
                }
            }
            checkRep();
            return set;
        }
        checkRep();
        return null;
    }

    /**
     * Returns the set of all vertices that have edges from source vertex
     * @param source the label associated with the source vertex
     * @spec.requires source != null
     * @return the set of all vertices that have edges from source vertex
     *         if no source or destination node exists, returns null
     */
    public Set<K> getOutgoing(K source) {
        checkRep();
        if (map.containsKey(source)) {
            Set<K> set = new HashSet<>();
            for (Edge<K,V> edge : map.get(source)) {
                set.add(edge.destLabel);
            }
            checkRep();
            return set;
        }
        checkRep();
        return null;
    }

    /**
     * Returns a set containing all the labels of the vertices within the graph
     * @return a set containing all the labels of the vertices within the graph
     */
    public Set<K> getVertices() {
        checkRep();
        return map.keySet();
    }

    /**
     * Checks if the graph is empty
     * @return true if this contains no vertices or edges, false otherwise
     */
    public boolean isEmpty() {
        checkRep();
        return size() == 0;
    }

    /**
     * Returns the number of vertices in the graph
     * @return the number of vertices in the graph
     */
    public int size() {
        checkRep();
        return map.keySet().size();
    }


    /**
     * Removes all vertices and edges from the graph, making it empty.
     * @spec.modifies this
     * @spec.effects this.isEmpty() and contains no nodes or edges
     */
    public void clear() {
        checkRep();
        map.clear();
    }

    /**
     * Checks that the representation invariant for this is held
     */
    private void checkRep() {
        assert map != null;

        if (DEBUG) {
            for (K vertex : map.keySet()) {
                assert vertex != null;
                Set<Edge<K,V>> set = map.get(vertex);
                assert set != null;
                for (Edge<K,V> edge : set) {
                    assert edge != null;
                    assert this.map.containsKey((edge.destLabel));
                }
            }
        }
    }

    /**
     * Represents an edge vector that points to a certain node
     */
    public static class Edge<K,V> {
        public final V edgeLabel;
        public final K destLabel;

        // RI: this.edgeLabel != null and this.destLabel != null
        // AF(this) = an edge vector, with the label this.edgeLabel, pointing towards a node with this.destLabel

        /**
         * creates an Edge with the given edge label and the label associated with the destination vertex of the edge
         * @param edgeLabel the label of the edge
         * @param destLabel the label of the destination vertex of this edge
         * @spec.requires edgeLabel != null and destLabel != null
         */
        public Edge(V edgeLabel, K destLabel) {
            this.edgeLabel = edgeLabel;
            this.destLabel = destLabel;
            checkRep();
        }

        /**
         * returns whether this is equal to another given object
         * @param o the other object to compare to
         * @return true if this represents the same edge as o, false otherwise
         */
        @Override
        public boolean equals(Object o) {
            checkRep();
            if (!(o instanceof Edge<?,?>))
                return false;

            Edge<?,?> other = (Edge<?,?>) o;

            checkRep();
            return edgeLabel.equals(other.edgeLabel) && destLabel.equals(other.destLabel);
        }

        /**
         * returns the hashcode for this edge
         * @return the hashcode for this edge
         */
        @Override
        public int hashCode() {
            checkRep();
            int result = edgeLabel.hashCode();
            result += (31 * result) + destLabel.hashCode();
            checkRep();
            return result;
        }

        /**
         * Checks that the representation invariant is held
         */
        private void checkRep() {
            assert this.edgeLabel != null;
            assert this.destLabel != null;
        }
    }
}
