package graph.junitTests;
import org.junit.Rule;
import org.junit.rules.Timeout;
import graph.Graph;
import org.junit.Test;

import static org.junit.Assert.*;
public class GraphTest {
    @Rule public Timeout globalTimeout = Timeout.seconds(10);
    @Test
    public void testHasEdge() {
        Graph<String, String> test = new Graph<>();
        assertFalse(test.hasEdge("n1", "n2", "e12"));

        test.addVertex("n1");
        assertFalse(test.hasEdge("n1", "n2", "e12"));

        test.addVertex("n2");
        assertFalse(test.hasEdge("n1", "n2", "e12"));

        test.addEdge("n1", "n2", "e12");
        assertTrue(test.hasEdge("n1", "n2", "e12"));
        assertFalse(test.hasEdge("n2", "n1", "e12"));
    }

    @Test
    public void testHasVertex() {
        Graph<String, String> test = new Graph<>();
        assertFalse(test.hasVertex("n1"));

        test.addVertex("n1");
        assertTrue(test.hasVertex("n1"));

        test.addVertex("n2");
        assertTrue(test.hasVertex("n2"));
    }

    @Test
    public void testIsEmpty() {
        Graph<String, String> test = new Graph<>();
        assertTrue(test.isEmpty());

        test.addVertex("n1");
        assertFalse(test.isEmpty());

        test.addVertex("n2");
        assertFalse(test.isEmpty());
    }

    @Test
    public void testSize() {
        Graph<String, String> test = new Graph<>();
        assertEquals(0, test.size());

        test.addVertex("n1");
        assertEquals(1, test.size());

        test.addVertex("n2");
        assertEquals(2, test.size());

        test.addEdge("n1", "n2", "e1");
        assertEquals(2, test.size());
    }

    @Test
    public void testClearVertex() {
        Graph<String, String> test = new Graph<>();
        addVertex(test);

        test.clear();
        assertEquals(0, test.getVertices().size());
        assertTrue(test.isEmpty());
    }

    @Test
    public void testClearEdges() {
        Graph<String, String> test = new Graph<>();
        addVertex(test);
        test.addEdge("n1", "n2", "e");
        test.addEdge("n1", "n3", "e");
        test.addEdge("n3", "n2", "e");
        test.addEdge("n2", "n4", "e");
        test.addEdge("n4", "n1", "e");
        test.addEdge("n1", "n1", "e");

        test.clear();
        assertEquals(0, test.getVertices().size());
        assertTrue(test.isEmpty());
    }

    private void addVertex(Graph<String, String> test) {
        test.addVertex("n1");
        test.addVertex("n2");
        test.addVertex("n3");
        test.addVertex("n4");
    }
}