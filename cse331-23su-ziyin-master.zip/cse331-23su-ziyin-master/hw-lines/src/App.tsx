/*
 * Copyright (C) 2023 Soham Pardeshi.  All rights reserved.  Permission is
 * hereby granted to students registered for University of Washington
 * CSE 331 for use solely during Autumn Quarter 2022 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.  Instructors
 * interested in reusing these course materials should contact the
 * author.
 */

import React, {Component, useRef} from "react";
import EdgeList from "./EdgeList";
import Map from "./Map";


// Allows us to write CSS styles inside App.css, any styles will apply to all components inside <App />
import "./App.css";
import {LatLngExpression} from "leaflet";
import {UW_LATITUDE_CENTER, UW_LONGITUDE_CENTER} from "./Constants";

const position: LatLngExpression = [UW_LATITUDE_CENTER, UW_LONGITUDE_CENTER];

interface AppState {
    userEdges : string[]
    userPosition: string[]
}
class App extends Component<{}, AppState> { // <- {} means no props.

    constructor(props: any) {
        super(props);
        this.state = {
            userEdges : [],
            userPosition: [],
        };
    }
    checkOnCampus(x1: number, y1: number): boolean {
        return (x1 >= 0 && x1 <= 4000 && y1 >= 0 && y1 <= 4000);
    }

    parseEdges(message : string, layer : boolean) {
        let final : string[] = [];
        if (layer) {
            final = final.concat(this.state.userEdges);
        }
        let all : string[] = message.split("\n");
        all = all.filter((element) => element.length != 0);
        for (let i = 0; i < all.length; i++) {
            let single : string[] = all[i].split(" ");
            single = single.filter((element) => element.length != 0)

            if (single.length != 5) {
                all = [];
                alert("Each Edge/Line needs 5 elements" + "\n" + "Currently Line " + (i+1) + " has " + single.length + " elements.");
                break;
            }

            let valid:boolean = true;
            for (let j = 0; j < single.length; j++) {
                if (j == 4 && (typeof single[j] !== "string" || !isNaN(+single[4]))) {
                    alert("Components must be of correct value" + "\n" + single[4] + " is not a string");
                    valid = false;
                    break;
                } else if (j !== 4 && isNaN(+single[j])) {
                    alert("Components must be of correct value" + "\n" + single[j] + " is not a number");
                    valid = false;
                    break;
                }
            }
            if (!valid) {
                break;
            }

            if (!this.checkOnCampus(+single[0], +single[1]) || !this.checkOnCampus(+single[2], +single[3])) {
                alert("Coordinates must be on campus (from 0 to 4000)!");
                all = [];
                break;
            }

            final = final.concat(single);
        }

        this.setState({
            userEdges:final
        });
    }

    setMarkers(message : string) {
        let all : string[] = message.split("\n");
        all = all.filter((element) => element.length != 0);
        for (let i = 0; i < all.length; i++) {
            let single : string[] = all[i].split(" ")
            single = single.filter((element) => element.length != 0);
            if (single.length != 3) {
                alert("Each Edge/Line needs 3 elements" + "\n" + "Currently Line " + (i+1) + " has " + single.length + " elements.");
                all = [];
                break;
            } else if (isNaN(+single[0]) || isNaN(+single[1]) || typeof single[2] != "string") {
                alert("Components must be of correct value");
                all = [];
                break;
            } else if (!this.checkOnCampus(parseInt(single[0]), parseInt(single[1]))) {
                alert("Coordinates must be on campus (from 0 to 4000)!");
                all = [];
                break;
            }

            this.setState({
                userPosition: this.state.userPosition.concat(single)
            })
        }
    }

    clear() {
        this.setState({
            userEdges: []
        })
    }

    clearMark() {
        this.setState({
            userPosition: []
        })
    }
    render() {
        return (
            <div>
                <h1 id="app-title">Line Mapper!</h1>
                <div>
                    <Map edges = {this.state.userEdges} markers = {this.state.userPosition} />
                </div>

                <EdgeList
                    onChange={(value:string) => {
                        this.parseEdges(value, false)
                    }}

                    onLayer={(value:string) => {this.parseEdges(value, true)}}

                    onMark={(value:string) => {this.setMarkers(value)}}

                    onClear={() => {this.clear()}}

                    clearMark={() => {this.clearMark()}}
                />
            </div>
        );
    }
}

export default App;
