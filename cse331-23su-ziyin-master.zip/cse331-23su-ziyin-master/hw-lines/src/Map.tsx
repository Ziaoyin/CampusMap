/*
 * Copyright (C) 2023 Soham Pardeshi.  All rights reserved.  Permission is
 * hereby granted to students registered for University of Washington
 * CSE 331 for use solely during Autumn Quarter 2022 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.  Instructors
 * interested in reusing these course materials should contact the
 * author.
 */

import L, { LatLngExpression } from "leaflet";
import React, { Component } from "react";
import {MapContainer, Marker, Popup, TileLayer} from "react-leaflet";
import "leaflet/dist/leaflet.css";
import MapLine from "./MapLine";
import { UW_LATITUDE_CENTER, UW_LONGITUDE_CENTER, UW_LONGITUDE, UW_LATITUDE, UW_LONGITUDE_OFFSET,
    UW_LATITUDE_SCALE, UW_LONGITUDE_SCALE, UW_LATITUDE_OFFSET} from "./Constants";
import icon from 'leaflet/dist/images/marker-icon.png'
import iconRetinaUrl from 'leaflet/dist/images/marker-icon-2x.png'
import iconShadow from 'leaflet/dist/images/marker-shadow.png'

const DefaultIcon = L.icon({
    iconUrl: icon,
    iconRetinaUrl: iconRetinaUrl,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    tooltipAnchor: [16, -28],
    shadowSize: [41, 41]
})


// This defines the location of the map. These are the coordinates of the UW Seattle campus
const position: LatLngExpression = [UW_LATITUDE_CENTER, UW_LONGITUDE_CENTER];

interface MapProps {
    edges : string[]
    markers : string[]
}

class Map extends Component<MapProps, {}> {

    /**
     * Converts x coordinate to longitude
     */
    xToLon(x: number): number {
        return UW_LONGITUDE + (x - UW_LONGITUDE_OFFSET) * UW_LONGITUDE_SCALE;
    }

    /**
     * Converts y coordinate to latitude
     */
    yToLat(y: number): number {
        return UW_LATITUDE + (y - UW_LATITUDE_OFFSET) * UW_LATITUDE_SCALE;
    }

    renderLines(lines : JSX.Element[]) {
        for (let i = 0; i < this.props.edges.length; i+=5) {
            lines.push(
                <MapLine key = {i} color={this.props.edges[i+4]} x1={+this.props.edges[i]} y1={+this.props.edges[i+1]} x2={+this.props.edges[i+2]} y2={+this.props.edges[i+3]}/>
            )

        }
    }

    renderMarkers(markers:JSX.Element[]) {

        for (let i = 0; i < this.props.markers.length; i+= 3) {

            markers.push(
                <Marker position={[this.yToLat(+this.props.markers[i+1]), this.xToLon(+this.props.markers[i])]} icon={DefaultIcon}>
                    <Popup>
                        {this.props.markers[i+2]}
                    </Popup>
                </Marker>
            )

        }
    }
    render() {
        let lines: JSX.Element[] = []

        this.renderLines(lines);
        this.renderMarkers(lines);

        return (
            <div id="map">
                <MapContainer
                    center={position}
                    zoom={15}
                    scrollWheelZoom={false}
                >

                    <TileLayer
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    {lines}
                </MapContainer>
            </div>
        );
    }
}

export default Map;
