/** Data structures used by the Pathfinder program */
package pathfinder.datastructures;
