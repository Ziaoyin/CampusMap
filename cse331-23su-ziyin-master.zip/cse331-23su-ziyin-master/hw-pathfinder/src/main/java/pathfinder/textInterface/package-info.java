/** The text interface for Pathfinder */
package pathfinder.textInterface;